from fastapi import FastAPI
from fastapi.responses import JSONResponse
import requests
import time

app = FastAPI()

window = []

ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

HEADERS = {
    "Authorization": f"Bearer {ACCESS_TOKEN}"
}

@app.get("/numbers/{number_id}")
def get_numbers(number_id: str):
    global window
    url = f"http://20.244.56.144/test/numbers/{number_id}" 

    window_prev = window.copy()

    try:
        start_time = time.time()
        response = requests.get(url, headers=HEADERS, timeout=0.5)
        duration = time.time() - start_time

        if response.status_code != 200:
            raise Exception("Non-200 response")

        data = response.json()
        numbers = data.get("numbers", [])

        for num in numbers:
            if num not in window:
                if len(window) >= 10:
                    window.pop(0)
                window.append(num)

        avg = round(sum(window) / len(window), 2) if window else 0.0

        return JSONResponse(content={
            "windowPrevState": window_prev,
            "windowCurrState": window.copy(),
            "numbers": numbers,
            "avg": avg
        })

    except Exception as e:
        print(f"⚠️ Exception: {e}")
        return JSONResponse(content={
            "windowPrevState": window_prev,
            "windowCurrState": window.copy(),
            "numbers": [],
            "avg": round(sum(window) / len(window), 2) if window else 0.0
        })
